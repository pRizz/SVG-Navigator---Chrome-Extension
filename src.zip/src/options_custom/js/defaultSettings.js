// Default settings
    
this.SVGNavigatorDefaultSettings = {
	"clickAndDragBehavior": "pan",
	"scrollSensitivity": 7,
	"invertScroll": false,
	"showDebugInfo": false,
};